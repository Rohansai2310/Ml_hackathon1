PathSnap UI laptop (Python 3.10+; no pip packages needed)

Extract this zip, then open a terminal in the extracted folder.
Keep both laptops on the same Wi-Fi. Start FastAPI on the server laptop first.
Run: python scripts/run_client.py --server http://SERVER_WIFI_IP:8000
Replace SERVER_WIFI_IP and port with the actual server address.
Open http://127.0.0.1:8501 in this laptop's browser.
Windows users can use py instead of python.
The server laptop keeps the model and dataset; neither is in this zip.
